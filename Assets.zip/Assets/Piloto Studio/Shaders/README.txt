Hello!

Import the desired rendering pipeline by double clicking on the .unitypackage file that corresponds to your installed pipeline.

If you are using either URP or HDRP, make sure the core RP package is installed. 

